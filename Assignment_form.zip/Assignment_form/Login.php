<?php
$cookie_name = "user";
$cookie_value = "John";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style type="text/css"> 

    body {
        height:100vh;
        display:flex;
        align-items:center;
        justify-content:center;
       
    }

    form {
        background-color:skyblue;
        color:white;
        font-size:20px;
        border: 1px solid black;
        border-radius:10px;
        padding: 20px 40px;
        text-align:center;

    }

    input {
        border:none;
        border-radius:10px;
        padding:10px 40px;
    }

    input[type="submit"] {
        background: blue;
        color: white;
        cursor: pointer;
    }


    </style>
</head>
<body>

    <form action="./welcome.php" method="POST">
        <h2>Login Form</h2>
        Name: <input type="text" name="name" required><br><br>
        E-mail: <input type="email" name="email" required><br><br>
        <input type="submit">
    </form>

</body>
</html>
