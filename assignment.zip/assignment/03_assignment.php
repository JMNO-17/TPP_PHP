<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $num1 = $_GET['num1'];
        $num2 = $_GET['num2'];

        $num = $num1 + $num2;

        if ($num1 >= 1 && $num1 <= 100 && $num2 >= 1 && $num2 <= 100) {
            echo "Result = $num";
        } else {
            echo "Invalid number";
        }
?>

</body>
</html>