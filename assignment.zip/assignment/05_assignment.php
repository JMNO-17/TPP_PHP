<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- Output 1 -->
    <?php
        for ($i = 1; $i <= 5; $i++) {
            echo str_repeat("*", $i) . "<br>";
        }
    ?>
    <br/>

    <!-- Output 2 -->
    <?php
        $rows = 5;
        for ($i = 1; $i <= $rows; $i++) {
            echo str_repeat("&nbsp;", $rows - $i);
            
            echo str_repeat("*", $i) . "<br>";           
        }
    ?>
    <br/>

    <!-- Output 3 -->
    <?php
    for ($i = 5; $i >= 1; $i--) {
            echo str_repeat("*", $i) . "<br>";
        }
    ?>
    <br/>

    <!-- Output 4 -->
    <?php
    $rows = 5;

        for ($i = 1; $i <= $rows; $i++) {
            echo str_repeat("&nbsp;", $rows - $i);

            echo str_repeat("*", 2 * $i - 1);
            echo "<br>";
        }
    ?>

    <br/>

    <!-- Output 5 -->
    <?php
    $rows = 5;

        for ($i = 1; $i <= $rows; $i++) {
            echo str_repeat("&nbsp;", $rows - $i);
            echo str_repeat("*", 2 * $i - 1);
            echo "<br>";
        }

        for ($i = $rows - 1; $i >= 1; $i--) {
            echo str_repeat("&nbsp;", $rows - $i);
            echo str_repeat("*", 2 * $i - 1);
            echo "<br>";
        }
    ?>



</body>
</html>