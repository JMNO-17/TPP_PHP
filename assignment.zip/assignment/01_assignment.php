<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 1</title>
</head>
<body>
    <?php
        $num = $_GET['num'];

        if($num >= 0 && $num <= 100){
            if ($num % 3 == 0 && $num % 5 == 0) {
                print("FizzBuzz");
            } else if ($num % 3 == 0) {
                print("Fizz");
            } else if ($num % 5 == 0) {
                print("Buzz");
            } else {
                print($num);
            }
        }else{
            print("Invalid number!");
        }
        
    ?>

</body>
</html>