<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 100px;
        }
        h2 {
            color: green;
        }
        p {
            color: #333;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: crimson;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>

    <?php
    if (isset($_COOKIE['username'])) {
        echo "<p>Your username (from cookie): " . htmlspecialchars($_COOKIE['username']) . "</p>";
    }
    ?>

    <a href="logout.php">Logout</a>
</body>
</html>
