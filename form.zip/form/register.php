<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username == '' || $password == '') {
        echo "Please fill in both fields. <a href='register.php'>Go back</a>";
        exit();
    }

    $file = 'users.txt';

    if (!file_exists($file)) {
        file_put_contents($file, '');
    }

    $users = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($users as $user) {
        list($savedUser,) = explode('|', $user);
        if ($savedUser == $username) {
            echo "Username already taken. <a href='register.php'>Try again</a>";
            exit();
        }
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    file_put_contents($file, $username . '|' . $hashed_password . "\n", FILE_APPEND);

    echo "Registration successful! <a href='index.php'>Login here</a>";
} else {
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        form {
            background-color: skyblue;
            color: white;
            font-size: 20px;
            border: 1px solid black;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
        }
         input {
            border: none;
            border-radius: 10px;
            padding: 10px 40px;
            margin: 10px 0;
        }
        input[type="submit"] {
            background: blue;
            color: white;
            cursor: pointer;
        }
    </style>    
</head>
<body>
    
    <form action="register.php" method="post">
        <h2>Register</h2>
        Username: <input type="text" name="username" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <input type="submit" value="Register">
    </form>
</body>
</html>

<?php
}
?>
