<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $file = 'users.txt';
    $found = false;

    if (file_exists($file)) {
        $users = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($users as $user) {
            list($savedUser, $savedPass) = explode('|', $user);
            if ($username === $savedUser && password_verify($password, $savedPass)) {
                $found = true;
                break;
            }
        }
    }

    if ($found) {
        $_SESSION['username'] = $username;
        setcookie("username", $username, time() + 3600, "/");
        header("location: welcome.php");
        exit();
    } else {
        echo "Invalid username or password. <a href='index.php'>Try again</a>";
    }
} else {
    header("location: index.php");
    exit();
}
?>
