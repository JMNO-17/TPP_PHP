<?php
session_start();

if (isset($_SESSION['username'])) {
    header("location: welcome.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style type="text/css"> 
    body {
        height:100vh;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    form {
        background-color:skyblue;
        color:white;
        font-size:20px;
        border: 1px solid black;
        border-radius:10px;
        padding: 40px;
        text-align:center;
    }
    input {
        border:none;
        border-radius:10px;
        padding:10px 40px;
    }
    input[type="submit"] {
        background: blue;
        color: white;
        cursor: pointer;
    }
    </style>
</head>
<body>

<form action="login.php" method="post">
    <h2>Login Form</h2>
    Username: <input type="text" name="username" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <input type="submit" value="Login">
    <p>Don't have an account? <a href="register.php">Register here</a></p>
</form>



</body>
</html>
